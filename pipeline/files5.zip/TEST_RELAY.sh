#!/bin/bash

echo "════════════════════════════════════════════════════════════"
echo "  TESTING WEBSOCKET RELAY - The Fix!"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "This tests the FIXED relay server that forwards messages."
echo ""

# Check if server is running
if ! lsof -i :8080 > /dev/null 2>&1; then
  echo "✗ Server is not running on port 8080"
  echo ""
  echo "Action: Start the server in another terminal:"
  echo "  $ ./ws_server.js"
  echo ""
  exit 1
fi

echo "✓ Server is running on port 8080"
echo ""
echo "CRITICAL: You MUST have a browser open at:"
echo "  http://localhost:8080/minimal"
echo ""
echo "The browser must be open BEFORE running this test!"
echo ""

read -p "Press Enter when browser is open at /minimal..."
echo ""

echo "Running test..."
echo ""
echo "Command:"
echo "  echo '[\"var go = function() { return [1, 0, 0, 1]; }; go\"]' | ./ws_sender.js"
echo ""
echo "──────────────────────────────────────────────────────────"

echo '["var go = function() { return [1, 0, 0, 1]; }; go"]' | ./ws_sender.js

RESULT=$?

echo "──────────────────────────────────────────────────────────"
echo ""

if [ $RESULT -eq 0 ]; then
  echo "✓✓✓ TEST PASSED! ✓✓✓"
  echo ""
  echo "What you should see:"
  echo ""
  echo "1. In SERVER terminal (ws_server.js):"
  echo "   - Client connected (total: 2)"
  echo "   - Received message, type: code"
  echo "   - Forwarding to other client"
  echo "   - Received message, type: ok"
  echo "   - Forwarding to other client"
  echo "   - Client disconnected (remaining: 1)"
  echo ""
  echo "2. In THIS terminal (ws_sender.js):"
  echo "   - Connected to ws://localhost:8080"
  echo "   - Sent 48 bytes"
  echo "   - Response from browser: {status: ok}"
  echo "   - ✓ SUCCESS"
  echo ""
  echo "3. In BROWSER:"
  echo "   - RED SQUARE on canvas"
  echo "   - Event log showing success"
  echo ""
  echo "If you see all three, the relay is working perfectly!"
  echo ""
else
  echo "✗✗✗ TEST FAILED ✗✗✗"
  echo ""
  echo "Common issues:"
  echo ""
  echo "1. 'Timeout: No response from browser'"
  echo "   → Browser is not open at http://localhost:8080/minimal"
  echo "   → Open it and run this test again"
  echo ""
  echo "2. 'Connection failed'"
  echo "   → Server is not running"
  echo "   → Check that ./ws_server.js is running"
  echo ""
  echo "3. Still hanging (no timeout):"
  echo "   → You're using OLD ws_sender.js without timeout"
  echo "   → Make sure all files are updated"
  echo ""
fi
