\ Simple gradient from black to white
x dup dup 1 0
0 0 drop drop drop drop
drop 1 1 1 1
